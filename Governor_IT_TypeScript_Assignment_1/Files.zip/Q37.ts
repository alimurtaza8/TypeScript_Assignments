function makeShirts(size: string = "large") {
    console.log(`shirt size is ${size}`);
}

makeShirts("medium");
makeShirts();
makeShirts("small");