let personsName = "\tname\t";
console.log(personsName);
console.log(personsName.trim());