var alienColor = "Green";
if (alienColor == "Green") {
    console.log("The player just earned 5 points.");
}
else {
    console.log("The version that fails will have no output.");
}
