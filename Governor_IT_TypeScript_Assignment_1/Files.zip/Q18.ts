let placesLocations = ["Karachi", "Makkah", "Madina", "USA", "Dubai"];
console.log(placesLocations);
console.log(placesLocations.sort());
console.log(placesLocations);
console.log(placesLocations.sort().reverse());
console.log(placesLocations);
console.log(placesLocations.reverse());
console.log(placesLocations.reverse());
console.log(placesLocations.sort());
console.log(placesLocations.sort().reverse());


