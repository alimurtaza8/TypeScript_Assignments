var userName = ["User1", "User2", "User3", "User4", "User5"];
for (var i = 0; i < userName.length; i++) {
    console.log("Hello ".concat(userName[i]));
}
