var personName = "Eric";
console.log("Hello ".concat(personName, ", would you like to learn some Python today?"));
