console.log("Addition", 4 + 4);
console.log("Subtraction", 12 - 4);
console.log("Multiplication", 2 * 4);
console.log("Divison", 16 / 2);