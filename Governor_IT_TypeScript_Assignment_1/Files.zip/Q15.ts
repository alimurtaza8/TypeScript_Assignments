let guestLists = ["Person1", "Person2", "Person3"];

console.log(`${guestLists[2]} can’t make the dinner`);
guestLists[2] = "NewPerson";
console.log(`Your are inviting to this dinner ${guestLists[0]}`);
console.log(`Your are inviting to this dinner ${guestLists[1]}`);
console.log(`Your are inviting to this dinner ${guestLists[2]}`);
