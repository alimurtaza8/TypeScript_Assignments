let aliencolor = "Yellow";

if (aliencolor == "Green") {
    console.log("The player just earned 5 points.");
}
else if (aliencolor == "Yellow") {
    console.log("The player earned 10 points");
}
else if (aliencolor == "Red") {
    console.log("The player earned 15 points");
}