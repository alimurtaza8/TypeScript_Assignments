function makeShirt(size) {
    console.log("Shirt size is: ".concat(size));
}
makeShirt("Large");
