let favoriteNumber = 10;
let messageForFavorite = `This is my Favorite Number: ${favoriteNumber}`;
console.log(messageForFavorite);