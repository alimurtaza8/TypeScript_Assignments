function makeShirt(size: string) {
    console.log(`Shirt size is: ${size}`)
}

makeShirt("Large");