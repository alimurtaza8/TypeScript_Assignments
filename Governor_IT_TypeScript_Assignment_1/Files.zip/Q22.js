var myArray = [1, 2, 3, 4, 5];
var indexError = myArray[20];
console.log(indexError);
var validIndex = myArray[2];
console.log(validIndex);
