function makeShirts(size) {
    if (size === void 0) { size = "large"; }
    console.log("shirt size is ".concat(size));
}
makeShirts("medium");
makeShirts();
makeShirts("small");
