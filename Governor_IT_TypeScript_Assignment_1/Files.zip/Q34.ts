let favoritePizzas = ["Margherita Supreme", "BBQ Chicken Delight", "Mediterranean Veggie Delight"];

for (let pizzas in favoritePizzas) {
    console.log(`I like ${favoritePizzas[pizzas]} pizza`);
}
console.log("I really love pizza!");