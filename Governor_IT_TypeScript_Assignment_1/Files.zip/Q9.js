var favoriteNumber = 10;
var messageForFavorite = "This is my Favorite Number: ".concat(favoriteNumber);
console.log(messageForFavorite);
