let mountains = ["Mount Everest", "Kilimanjaro", "Rocky Mountains", "Alps", "Andes"];
let rivers = ["Amazon River", "Nile River", "Ganges River", "Mississippi River", "Danube River"];
let countries = ["United States", "India", "Brazil", "China", "Australia"];
let cities = ["Tokyo", "Paris", "New York City", "Sydney", "Cairo"];
let languages = ["English", "Spanish", "Mandarin Chinese", "Hindi", "French"];

console.log(mountains);
console.log(rivers);
console.log(countries);
console.log(cities);
console.log(languages);