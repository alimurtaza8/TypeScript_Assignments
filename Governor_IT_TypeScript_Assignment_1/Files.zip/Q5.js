var famousQuote = '"A person who never made a mistake never tried anything new."';
var famousAuthor = "Albert Einstein";
var message = famousAuthor + "," + famousQuote;
console.log(message);
