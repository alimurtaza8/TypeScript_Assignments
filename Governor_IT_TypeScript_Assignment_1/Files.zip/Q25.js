var alien_color = "Yellow";
if (alien_color == "Green") {
    console.log("The player just earned 5 points.");
}
else {
    console.log("The player just earned 10 points");
}
