var quote = '"A person who never made a mistake never tried anything new."';
var author = "Albert Einstein";
console.log("".concat(author, ",").concat(quote));
