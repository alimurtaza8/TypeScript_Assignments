let animalNames = ["Cat", "Dog", "Rabbits"];

for (let animal in animalNames) {
    console.log(`A ${animalNames[animal]} would make a great pet`);
}

console.log(`${animalNames[0]} is a great pet`);