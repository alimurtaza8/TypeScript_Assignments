var guestList = ["Person1", "Person2", "Person3"];
console.log("Your are inviting to this dinner ".concat(guestList[0]));
console.log("Your are inviting to this dinner ".concat(guestList[1]));
console.log("Your are inviting to this dinner ".concat(guestList[2]));
