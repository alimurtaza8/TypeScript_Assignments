let personName = "Eric";
console.log(`Hello ${personName}, would you like to learn some Python today?`);