function cityCountry(city: string, country: string) {
    console.log(`${city},${country}`);
}

cityCountry("Karachi", "Pakistan");
cityCountry("New York", "USA");
cityCountry("Paris", "France");
