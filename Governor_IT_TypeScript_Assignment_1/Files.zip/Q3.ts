let nameOfPerson = "Name";
console.log(nameOfPerson.toLowerCase());
console.log(nameOfPerson.toUpperCase());
console.log(nameOfPerson);