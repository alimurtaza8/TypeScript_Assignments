function cityCountry(city, country) {
    console.log("".concat(city, ",").concat(country));
}
cityCountry("Karachi", "Pakistan");
cityCountry("New York", "USA");
cityCountry("Paris", "France");
