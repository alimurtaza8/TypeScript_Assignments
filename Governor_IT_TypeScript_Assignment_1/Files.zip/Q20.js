var store = ["mountains", "rivers", "countries", "cities", "languages", "cars"];
console.log(store);
