let userName = ["User1", "User2", "User3", "User4", "User5"];

for (let i = 0; i < userName.length; i++) {
    console.log(`Hello ${userName[i]}`);
}