let famousQuote = '"A person who never made a mistake never tried anything new."';
let famousAuthor = "Albert Einstein";
let message = famousAuthor + "," + famousQuote;
console.log(message);