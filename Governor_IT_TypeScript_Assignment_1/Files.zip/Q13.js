var favoriteCars = ["Audi", "BMW", "Supra", "ferrari"];
console.log("I would like to own a ".concat(favoriteCars[0], " car"));
console.log("I would like to own a ".concat(favoriteCars[1], " car"));
console.log("I would like to own a ".concat(favoriteCars[2], " car"));
console.log("I would like to own a ".concat(favoriteCars[3], " car"));
