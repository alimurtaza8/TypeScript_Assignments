let favoriteCars = ["Audi", "BMW", "Supra", "ferrari"];
console.log(`I would like to own a ${favoriteCars[0]} car`);
console.log(`I would like to own a ${favoriteCars[1]} car`);
console.log(`I would like to own a ${favoriteCars[2]} car`);
console.log(`I would like to own a ${favoriteCars[3]} car`);