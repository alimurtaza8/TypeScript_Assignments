// This program print a greeting message
let greet = "Good Morning";
console.log(greet);

// This program prints your age
let age = 22;
console.log(age);