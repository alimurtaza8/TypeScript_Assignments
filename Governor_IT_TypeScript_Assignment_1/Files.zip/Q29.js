var favoriteFruits = ["Apple", "Orange", "bananas"];
if (favoriteFruits.includes("Grapes")) {
    console.log("You really like Grapes!");
}
else if (favoriteFruits.includes("Apple")) {
    console.log("You really like Apple!");
}
else if (favoriteFruits.includes("Mangoes")) {
    console.log("You really like Mangoes!");
}
else if (favoriteFruits.includes("Orange")) {
    console.log("You really like Orange!");
}
else if (favoriteFruits.includes("bananas")) {
    console.log("You really like bananas!");
}
