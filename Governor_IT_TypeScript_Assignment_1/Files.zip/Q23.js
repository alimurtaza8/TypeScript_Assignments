// True
var car = "Honda";
console.log(car == "Honda");
var car1 = "Honda";
console.log(car == car1);
var car2 = "Civic";
console.log(car2 == "Civic");
var num = 10;
console.log(num == 10);
var num2 = 10;
console.log(num2 == num);
//False
console.log(num2 == 20);
console.log(car == "Civic");
console.log(car1 == car2);
console.log(num == 80);
var car3 = "BMW";
console.log(car3 == car1);
