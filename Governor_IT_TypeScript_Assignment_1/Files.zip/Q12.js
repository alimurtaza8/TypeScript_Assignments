var friendNames = ["Zain", "Izhan", "Shajeel"];
console.log("Hi ".concat(friendNames[0]));
console.log("Hi ".concat(friendNames[1]));
console.log("Hi ".concat(friendNames[2]));
