let friendNames = ["Zain", "Izhan", "Shajeel"];
console.log(`Hi ${friendNames[0]}`);
console.log(`Hi ${friendNames[1]}`);
console.log(`Hi ${friendNames[2]}`);