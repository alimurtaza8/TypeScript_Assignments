var favoritePizzas = ["Margherita Supreme", "BBQ Chicken Delight", "Mediterranean Veggie Delight"];
for (var pizzas in favoritePizzas) {
    console.log("I like ".concat(favoritePizzas[pizzas], " pizza"));
}
console.log("I really love pizza!");
