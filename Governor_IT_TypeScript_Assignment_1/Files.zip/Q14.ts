let guestList = ["Person1", "Person2", "Person3"];
console.log(`Your are inviting to this dinner ${guestList[0]}`);
console.log(`Your are inviting to this dinner ${guestList[1]}`);
console.log(`Your are inviting to this dinner ${guestList[2]}`);