const myArray: number[] = [1, 2, 3, 4, 5];
const indexError = myArray[20];
console.log(indexError);

const validIndex = myArray[2];
console.log(validIndex);


