let friendsName = ["Zain", "Izhan", "Shajeel"];
console.log(friendsName[0]);
console.log(friendsName[1]);
console.log(friendsName[2]);