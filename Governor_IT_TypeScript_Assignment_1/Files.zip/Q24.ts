let alienColor = "Green";

if (alienColor == "Green") {
    console.log("The player just earned 5 points.");
}

